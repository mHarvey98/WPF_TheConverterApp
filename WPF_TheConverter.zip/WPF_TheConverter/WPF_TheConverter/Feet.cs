﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPF_TheConverter
{
    public class Feet
    {
        private double feet;

        public double MyFeet
        {
            get { return feet; }
            set { feet = value; }
        }
    }
}
