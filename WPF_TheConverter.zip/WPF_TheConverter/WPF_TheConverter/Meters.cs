﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPF_TheConverter
{
    public class Meters
    {
        private double meters;

        public double MyMeters
        {
            get { return meters; }
            set { meters = value; }
        }

    }
}
