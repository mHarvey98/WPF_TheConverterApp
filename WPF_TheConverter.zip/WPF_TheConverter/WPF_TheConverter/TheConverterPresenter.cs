﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPF_TheConverter
{
    public class TheConverterPresenter
    {
        private Feet _currentFeet;
        private Meters _currentMeters;

        public Feet CurrentFeet
        {
            get { return _currentFeet; }
            set { _currentFeet = value; }
        }

        public Meters CurrentMeters
        {
            get { return _currentMeters; }
            set { _currentMeters = value; }
        }

        public TheConverterPresenter()
        {
            InitializeDataContext();
        }

        private void InitializeDataContext()
        {
            _currentFeet = new Feet()
            {
                MyFeet = 0.0
            };

            _currentMeters = new Meters()
            {
                MyMeters = 0.0
            };
        }

        public void ExitApplication()
        {
            Environment.Exit(0);
        }
    }
}
